OVERVIEW
---------
The Organic Groups Subgroups module (also referred to as the 'og-subgroups' 
module), provides users the ability to inherit permission on subgroups, 
since Organic groups 7 a group can be part of an other group so we already got 
the hierarchy system in place, what is missing is the ability of a parent group 
member to automatically get the same permissions on his subgroups, since they 
are not necessarily a group member on each and every group, they will not get 
access to the same permission.


